var express = require("express");
var app = express();
var mysql = require('mysql');
var jwt = require('jsonwebtoken');
var bcrypt =require('bcrypt');

//connectin Mysql
var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "root",
  database:"user"
});

con.connect(function(err) {
  if (err) {
    console.error('error connecting: ' + err.stack);
    return;
  }
  console.log('connected as id ' + con.threadId);
});

// test
app.get('/', function(req, res) {
  res.json({ message: 'hooray login works!!' });

});

// test route to make sure everything is working (accessed at GET http://localhost:8080/api)
app.post('/', function(req, res) {

  var email = req.body.username;
  var password = req.body.password;

  var user = {
    "username": req.body.username,
    "password": req.body.password
  }

  console.log("Body: " + JSON.stringify(req.body));

  const saltRounds = 10;
  const myPlaintextPassword = req.body.password;
  var hash = bcrypt.hashSync(myPlaintextPassword, saltRounds);

  var decrypt_password = bcrypt.compareSync(myPlaintextPassword, hash);

  con.query('SELECT email,password FROM worker UNION SELECT email,password FROM employer WHERE email = ?',[email],
   function (error, results, fields) {
  if (error) {
    // console.log("error ocurred",error);
    res.send({
      "code":400,
      "failed":"error ocurred"
    })
  }else{
    //console.log('The solution is: ', results);
    if(results.length >0){
      if(results[0].password == password){
        console.info(password);
        res.send({
          "code":200,
          "success":"login successful",
          "category":results[0].skills
            });
      }
      else{
        console.log(password);
        res.send({
          "code":204,
          "success":"Username and password does not match"
            });
      }
    }
    else{
      res.send({
        "code":204,
        "success":"Email does not exits"
          });
    }
  }

  });
});

module.exports =  app;
