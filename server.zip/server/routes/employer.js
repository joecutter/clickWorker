var express = require("express");
var app = express();
var mysql = require('mysql');

//connectin Mysql
var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "root",
  database:"user"
});

con.connect(function(err) {
  if (err) {
    console.error('error connecting: ' + err.stack);
    return;
  }
  console.log('connected as id ' + con.threadId);
});


/*
post JOB BY Employer  
*/

//post A Job
app.post('/', function(req, res) {

  var date = req.body.date;
  var post = req.body.post;

    var job ={
      'title':req.body.title,
      'when_ago' :req.body.when,
      'date' : req.body.date,
      'post' : req.body.post
    }
    console.log("Body: " + JSON.stringify(req.body));

    con.query('INSERT INTO employer_post SET ?',job,function (error, results, fields) {
      if (error) {
      console.log("error ocurred",error);
      res.send({
        "code":400,
        "failed":"error ocurred"
      })
    }else{
      console.log('The solution is: ', results);
      res.send({
        "code":200,
        "success":"Job posted sucessfully"
          });
    }
		});
});

//get A Job
app.get('/postedJobs', function(req, res) {

  con.query('SELECT * FROM employer_post',function (error, results, fields) {
      if (error) {
      console.log("error ocurred",error);
      res.send({
        "code":400,
        "failed":"error ocurred"
      })
    }else{
      console.log('The solution is: ', results);
      res.send({
        "code":200,
        "success":results
          });
        }
		});
});


/*
post Employer profie 
  And
post Company Profile
*/

// post employer
app.post('/employerProfile', function(req, res) {

  var date = req.body.date;
  var post = req.body.post;

    var info ={
      'email':req.body.email,
      'password' :req.body.pwd,
      'fname' : req.body.fname,
      'lname' : req.body.lname
    }
    console.log(req.body);

    con.query('INSERT INTO employer SET ?',info,function (error, results, fields) {
      if (error) {
      console.log("error ocurred",error);
      res.send({
        "code":400,
        "failed":"error ocurred"
      })
    }else{
      console.log('The solution is: ', results);
      res.send({
        "code":200,
        "success":"employer registered sucessfully"
          });
    }
		});
});

// post CompanyProfile 
app.post('/employerCompany', function(req, res) {

  var date = req.body.date;
  var post = req.body.post;
  

    var info ={
      'company': req.body.company,
      'country': req.body.country,
      'location': req.body.location,
      'street': req.body.street,
      'cell_no': req.body.cell_no
    }
    console.log(req.body);

    con.query('INSERT INTO company_info SET ? ',info, function (error, results, fields) {
      if (error) {
      console.log("error ocurred",error);
      res.send({
        "code":400,
        "failed":"error ocurred"
      })
    }else{
      console.log('The solution is: ', results);
      res.send({
        "code":200,
        "success":"company registered sucessfully"
          });
    }
		});
});

/*
get Employer profie 
  And
get Company Profile
*/

//get Employer Info
app.post('/employerDetails', function(req, res) {

  var email = req.body.email;

    con.query('SELECT * FROM employer WHERE email = ?',[email],function (error, results, fields) {
      if (error) {
        // console.log("error ocurred",error);
        res.send({
          "code":400,
          "failed":"error ocurred"
        })
      }else{
        //console.log('The solution is: ', results);
        if(results.length >0){
          if(results[0].email == email){
            console.log(email);
            con.query('SELECT * FROM company_info',function (error, data, fields) {
              if (error) {
              console.log("error ocurred",error);
              res.send({
                "code":400,
                "failed":"error ocurred"
              })
            }else{
              console.log('The solution is: ', results);
              res.send({
                "success":data,
                "category":results
                  });
            }
          });
          }
          else{
            console.log(email);
            res.send({
              "code":204,
              "success":"Username and password does not match"
                });
          }
        }
        else{
          console.log(email);
          res.send({
            "code":204,
            "success":"Email does not exits"
              });
        }
      }
    });
  
  });
  
  //get companydetails Info
  app.get('/companyDetails', function(req, res) {
    
      con.query('SELECT * FROM company_info',
      function (error, results, fields) {
        if (error) {
        console.log("error ocurred",error);
        res.send({
          "code":400,
          "failed":"error ocurred"
        })
      }else{
        console.log('The solution is: ', results);
        res.send({
          "success":results
            });
      }
      });
    
    });

module.exports =  app;
