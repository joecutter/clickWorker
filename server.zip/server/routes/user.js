/**
 * Created by user on 7/4/17.
 */
var express = require("express");
var app = express();
var mysql = require('mysql');

//connectin Mysql
var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "root",
  database:"user"
});

con.connect(function(err) {
  if (err) {
    console.error('error connecting: ' + err.stack);
    return;
  }
  console.log('connected as id ' + con.threadId);
});

//get Applied for job
//retrive CV
app.get('/retrive', function(req, res) {

  con.query('SELECT * FROM applied_jobs',function (error, results, fields) {
    if (error) {
    console.log("error ocurred",error);
    res.send({
      "code":400,
      "failed":"error ocurred"
    })
  }else{
    console.log('The solution is: ', results);
    res.send({
      "data":results
        });
   }
});

});

//post Applied for job
//Send CV
app.post('/', function(req, res) {

  var date= new Date()

  var applied ={
    'title':req.body.title,
    'created' :date,
    'date' : req.body.date,
    'post' : req.body.post,
    'letter': req.body.letter
  }

  console.log("Body: " + JSON.stringify(req.body));
  
  con.query('INSERT INTO applied_jobs SET ?',applied,function (error, results, fields) {
        if (error) {
        console.log("error ocurred",error);
        res.send({
          "code":400,
          "failed":"error ocurred"
        })
      }else{
        console.log('The solution is: ', results);
        res.send({
          "code":200,
          "success":"job applied sucessfully"
            });
      }
    });

});

module.exports =  app;
