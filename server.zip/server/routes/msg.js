var express = require("express");
var app = express();
var mysql = require('mysql');

//connectin Mysql
var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "root",
  database:"user"
});


// Post Mesages
app.get('/', function(req, res) {
  res.json({ message: 'hooray!!' });
});

// Get Mesages
app.get('/', function(req, res) {
  con.query('SELECT * FROM msg',function(err, docs){
      if (err) {
        handleError(res, err.message, "Failed to get messages.");
      } else {
        res.status(200).json(docs);
      }
  });
});

module.exports =  app;
