/**
 * Created by user on 7/4/17.
 */
var express = require("express");
var app = express();

// test route to make sure everything is working (accessed at GET http://localhost:8080/api)
app.get('/', function(req, res) {
  res.json({ message: 'hooray! welcome to our api!' });
});

module.exports =  app;
