var express = require("express");
var app = express();
var mysql = require('mysql');

var jwt = require('jsonwebtoken');
var bcrypt =require('bcrypt'); 

//connectin Mysql
var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "root",
  database:"user"
});

con.connect(function(err) {
  if (err) {
    console.error('error connecting: ' + err.stack);
    return;
  }
  console.log('connected as id ' + con.threadId);
});


// test
app.get('/', function(req, res) {
  res.json({ message: 'hooray! welcome to our Register!' });

});

// add User
app.post('/', function(req, res) {
  
  const saltRounds = 10;
  const myPlaintextPassword = req.body.pwd;

  var hash = bcrypt.hashSync(myPlaintextPassword, saltRounds);
  // Store hash in your password DB.

  console.log(profile);

var profile ={
    'email':req.body.email,
    'password' : hash,
    'purpose' : req.body.status,
    'fname' : req.body.fname,
    'lname' : req.body.lname,
    'location' : req.body.location,
    'phone_no' : req.body.cell_no,
    'DOB' : req.body.date,
    'sex' : req.body.gender
  }

  console.info("Body: " + JSON.stringify(req.body));

  con.query('INSERT INTO worker SET ?',profile,function (error, results, fields) {
    
  if (error) {
    console.log("error ocurred",error);
    res.send({
      "code":400,
      "failed":"error ocurred"
    })
  }else{
    console.log('The solution is: ', results);
    res.send({
      "code":200,
      "success":"user registered sucessfully",
        });
     }
   });
   
});
    
    // add User
    app.post('/worker', function(req, res) {
    
      var profile ={
        'education':req.body.education,
        'certificate':req.body.certificate,
        'experience':req.body.experience,
        'jobType':req.body.jobType,
        'description':req.body.desc, 
        'status':req.body.status,
        'avail':req.body.avail
      }
     
    
        console.info("Body: " + JSON.stringify(req.body));
    
        
        con.query('INSERT INTO worker_info SET ?',profile,function (error, results, fields) {
          if (error) {
          console.log("error ocurred",error);
          res.send({
            "code":400,
            "failed":"error ocurred"
          })
        }else{
          console.log('The solution is: ', results);
          res.send({
            "code":200,
            "success":"user registered sucessfully"
              });
        }
        });
    });
    



module.exports =  app;
