var express = require("express");
var app = express();
var mongojs = require('mongojs');
var db = mongojs('mongodb://click_admin:password@ds161873.mlab.com:61873/click_db',['user_coll']);
var mysql = require('mysql');

//connectin Mysql
// var con = mysql.createConnection({
//   host: "localhost",
//   user: "root",
//   password: "root",
//   database:"user"
// });

// con.connect(function(err) {
//   if (err) {
//     console.error('error connecting: ' + err.stack);
//     return;
//   }
//   console.log('connected as id ' + con.threadId);
// });

//Get worker Profile
app.get('/', function(req, res) {
  db.user_coll.find( function (error, docs) {
    if (error) {
    console.log("error ocurred",error);
    res.send({
      "code":400,
      "failed":"error ocurred"
    })
  }else{
    console.log('The solution is: ', docs);
    res.send({
      "code":200,
      "success":"user profile retrived sucessfully",
      "data":docs
        });
  }
  });
});

//Add worker Profile
app.post('/', function(req, res) {
  var today = new Date();
  var profile = {
     'username': req.body.username,
     'email' : req.body.email,
     'DOB' : req.body.date,
     'gender' : req.body.gender,
     'education' : req.body.education,
     'certificate' : req.body.certificate,
     'experience' : req.body.experience,
     'job' : req.body.jobType,
     'description' : req.body.desc,
     'potfolio' : req.body.potfolio,
     'status' : req.body.status,
     'date' : today
  };

  console.info("Body: " + JSON.stringify(req.body));

  //mongodb query
  db.user_coll.insert(profile, function(err, docs){
    if (error) {
    console.log("error ocurred",error);
    res.send({
      "code":400,
      "failed":"error ocurred"
    })
  }else{
    console.log('The solution is: ', docs);
    res.send({
      "code":200,
      "success":"user profile updated sucessfully"
        });
      }
  });

});

module.exports =  app;


//backup

//connectin Mysql
// var con = mysql.createConnection({
//   host: "localhost",
//   user: "root",
//   password: "root",
//   database:"user"
// });
//
// con.connect(function(err) {
//   if (err) {
//     console.error('error connecting: ' + err.stack);
//     return;
//   }
//   console.log('connected as id ' + con.threadId);
// });
//
// //Get worker Profile
// app.get('/', function(req, res) {
//   con.query('SELECT * FROM profiletbl', function (error, results, fields) {
//     if (error) {
//     console.log("error ocurred",error);
//     res.send({
//       "code":400,
//       "failed":"error ocurred"
//     })
//   }else{
//     console.log('The solution is: ', results);
//     res.send({
//       "code":200,
//       "success":"userprofile updated sucessfully",
//       "data":results
//         });
//   }
//   });
// });
//
// //Add worker Profile
// app.post('/', function(req, res) {
//   var today = new Date();
//   var profile = {
//      'username': req.body.username,
//      'email' : req.body.email,
//      'DOB' : req.body.date,
//      'gender' : req.body.gender,
//      'education' : req.body.education,
//      'certificate' : req.body.certificate,
//      'experience' : req.body.experience,
//      'job' : req.body.jobType,
//      'description' : req.body.desc,
//      'potfolio' : req.body.potfolio,
//      'status' : req.body.status,
//      'date' : today
//
//   }
//
//   console.info("Body: " + JSON.stringify(req.body));


  //SQL query
  // con.query('INSERT INTO profiletbl SET ?',profile, function (error, results, fields) {
  //   if (error) {
  //   console.log("error ocurred",error);
  //   res.send({
  //     "code":400,
  //     "failed":"error ocurred"
  //   })
  // }else{
  //   console.log('The solution is: ', results);
  //   res.send({
  //     "code":200,
  //     "success":"userprofile updated sucessfully"
  //       });
  // }
  // });
// });
