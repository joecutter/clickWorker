var express = require("express");
var app = express();
var mysql = require('mysql');

//connectin Mysql
var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "root",
  database:"user"
});

con.connect(function(err) {
  if (err) {
    console.error('error connecting: ' + err.stack);
    return;
  }
  console.log('connected as id ' + con.threadId);
});

// get AppliedJob
app.get('/', function(req, res) {
  con.query('SELECT * FROM employer_post',function (error, results, fields) {
    if (error) {
    console.log("error ocurred",error);
    res.send({
      "code":400,
      "failed":"error ocurred"
    })
  }else{
    console.log('The solution is: ', results);
    res.send({
      "code":200,
      "success":"get applied jobs sucessfully",
      "message":results
        });
  }
  });
});

//post AppliedJob
app.post('/', function(req, res) {

  var applied = {
    'date':req.body.Date,
    'post':req.body.Post,
    'title':req.body.Title
  }

  console.log(req.body)

  con.query('INSERT INTO posttbl SET ?',applied,function (error, results, fields) {
    if (error) {
    console.log("error ocurred",error);
    res.send({
      "code":400,
      "failed":"error ocurred"
    })
  }else{
    console.log('The solution is: ', results);
    res.send({
      "code":200,
      "success":"job applied sucessfully"
        });
  }
  });

});

module.exports =  app;
