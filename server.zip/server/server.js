var express    = require('express');        // call express
var app        = express();                 // define our app using express
var cors       = require('cors');
var logger     = require('morgan');
var bodyParser = require('body-parser');
var path       = require('path');
var passport   = require('passport');
var session    = require('express-session');
var env        = require('dotenv').load();
var request = require('request');

var login = require("./routes/login");
var register = require("./routes/signup");
var msg = require("./routes/msg");
var histo = require("./routes/histo");
var profile = require("./routes/profile");
var user = require("./routes/user");
var index = require("./routes/index");
var employer = require("./routes/employer");

//configure DB connection
const config = require('./config/config');
const db = require("./config/db");


//configure Security middleware
// For Passport
app.use(session({ secret: 'keyboard cat',resave: true, saveUninitialized:true})); // session secret

app.use(passport.initialize());

app.use(passport.session()); // persistent login sessions


//Mpesa
  consumer_key = "V46CFFHhQwk6wH3nXMQ9NnngfNaADW2U",
  consumer_secret = "A2PaKmKrWaTIuGxO",
  url = "https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials"
  auth = "Basic " + new Buffer(consumer_key + ":" + consumer_secret).toString("base64");

  request(
    {
      url : url,
      headers : {
        "Authorization" : auth
      }
    },
    function (error, response, body) {
      // TODO: Use the body object to extract OAuth access token
    }
  )

//View Engine
app.set('views',path.join(__dirname,'/src'));
app.set('view engine','ejs');
app.engine('html',require('ejs').renderFile);

//Set Static Folder
app.use(express.static(path.join(__dirname,'src')));

// configure middleware
app.use(cors());
app.use(logger('dev'));

// configure app to use bodyParser()
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

var port = process.env.PORT || 3100;        // set our port


// REGISTER OUR ROUTES
app.use('/',index);
app.use('/user',user);
app.use('/login',login);
app.use('/register',register);
app.use('/msg',msg);
app.use('/profile',profile);
app.use('/histo',histo);
app.use("/employer",employer);


// START THE SERVER
app.listen(port);
console.log('Magic happens on port ' + port);

// Generic error handler used by all endpoints.
function handleError(res, reason, message, code) {
  console.log("ERROR: " + reason);
  res.status(code || 500).json({"error": message});
}
